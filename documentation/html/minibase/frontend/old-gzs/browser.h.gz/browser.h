# include "catalog.h"
# include "util.h"

#ifndef BROWSER_H
#define BROWSER_H


#define MAXLENGTH 100

enum { OK, UNKNOWN, OPENERROR, WRONGARG };

// Browser class only exists as an instance of a utility operation

class Browser {
 public:

 // Open DB, RelCat, and Attr Cat
 Browser();

 // clean up all opened stuffs, if any
 ~Browser();

 // return list of databases available
 Status GetDBList(char* dblist);

 // return list of relations in the opened db
 Status GetDBInfo(char* dbname, char* rellist, int &dbcnt, int MAXCOUNT);

 // return list of attr. in the opened relation
 Status GetRELInfo(char* attrname, char* attrlist, int &relcnt, int MAXCOUNT);

 // return specific info on an attr.
 Status GetATTRInfo(char* attrname, indexType& type, int& bucketcnt);

 // prints record in an opened relation
 Status Print()

 // return pointer to current DB, relations, attributes, respectively
 DB* CurrentDB() { return OpenedDB;} 
 RelCatalog* CurrentREL() { return OpenedRelCat;} 
 AttrCatalog* CurrentATTR() { return OpenedAttrCat; }
	
 Status ResetStates();


 private:

 // internal bookkeeping
 char DBname[MAXLENGTH];
 char RELname[MAXLENGTH];
 char ATTRname[MAXLENGTH];

 // some state info.
 Error   error;
 DB*     OpenedDB = NULL;
 RelCatalog* OpenedRelCat = NULL:
 AttrCatalog* OpenedAttrCat = NULL;

}

Browser* CurrentBrowser = NULL;

#endif
