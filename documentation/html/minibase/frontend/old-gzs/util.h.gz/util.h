#ifndef UTIL_H
#define UTIL_H

#include "catalog.h"
#include "minirel.h"

// convert from char* to index type
int GetIndexType(char* type) ;

// convert from char* to data type
int GetDataType ( char* typename ) ;

// init all managers
Status Init_Minirel();

// init all interpreters
Status Init_GUI();

#endif
